# What if sunlight switched off?

PROVISIONAL DEMONSTRATION — REVIEW REQUIRED

What if sunlight switched off? Imagine the Sun stays in place, but suddenly stops emitting light.

We would not notice immediately. Light already on its way would still travel toward Earth.

Sunlight takes about eight minutes to reach us. Only after that delay would the sky change.

In this scenario the Sun still has its mass. Darkness alone would not fling Earth out of its orbit.

Earth would begin losing heat without its usual sunlight. Cooling and ecological effects would unfold over time.

The lesson is to define the question. Turning off the light and removing the Sun are different experiments.